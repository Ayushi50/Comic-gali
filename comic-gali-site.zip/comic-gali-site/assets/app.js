/* Comic Gali — small behaviours for the static mockup.
   Everything is driven by data-attributes so it is easy to replace with a framework later. */
(function () {
  var root = document.documentElement;

  /* 1. Light / dark mode, remembered between pages */
  function setTheme(t) {
    root.setAttribute('data-theme', t);
    try { localStorage.setItem('cg-theme', t); } catch (e) {}
  }

  /* 2. Library: filter chips + search */
  var filter = 'all';
  function applyLibrary() {
    var q = (document.getElementById('q') || {}).value || '';
    q = q.trim().toLowerCase();
    var sections = document.querySelectorAll('[data-section]');
    Array.prototype.forEach.call(sections, function (sec) {
      var kind = sec.getAttribute('data-section');
      var allowed = filter === 'all' || filter === kind || (filter === 'audio' && kind === 'kahani');
      var visible = 0;
      Array.prototype.forEach.call(sec.querySelectorAll('.cover'), function (c) {
        var title = (c.querySelector('.ct') || c).textContent.toLowerCase();
        var hasAudio = /suno/i.test(c.textContent.replace(title, ''));
        var show = (!q || title.indexOf(q) !== -1) && (filter !== 'audio' || hasAudio);
        c.classList.toggle('is-hidden', !show);
        if (show) visible++;
      });
      sec.classList.toggle('is-hidden', !allowed || visible === 0);
    });
  }

  /* 3. Reader: page number + thumbnails */
  var thumbs = document.querySelector('[data-thumbs]');
  var total = thumbs ? parseInt(thumbs.getAttribute('data-total'), 10) || 1 : 1;
  var page = thumbs ? parseInt(thumbs.getAttribute('data-page'), 10) || 1 : 1;
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function renderReader() {
    if (!thumbs) return;
    var start = Math.min(Math.max(1, page - 1), Math.max(1, total - 3));
    var html = '';
    for (var n = start; n < start + 4 && n <= total; n++) {
      html += '<button type="button" class="th' + (n === page ? ' on' : '') + '" data-page-go="' + n + '" aria-label="Page ' + n + '"' + (n === page ? ' aria-current="page"' : '') + '>' + pad(n) + '</button>';
    }
    thumbs.innerHTML = html;
    var label = document.querySelector('[data-page-label]');
    if (label) label.textContent = pad(page);
  }
  function goTo(n) { page = Math.min(total, Math.max(1, n)); renderReader(); }

  document.addEventListener('click', function (e) {
    var el;
    if ((el = e.target.closest('[data-theme-toggle]'))) {
      setTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    } else if ((el = e.target.closest('[data-play-toggle]'))) {
      var on = document.body.classList.toggle('is-playing');
      el.setAttribute('aria-pressed', on ? 'true' : 'false');
    } else if ((el = e.target.closest('[data-filter]'))) {
      filter = el.getAttribute('data-filter');
      Array.prototype.forEach.call(document.querySelectorAll('[data-filter]'), function (c) {
        var active = c === el;
        c.classList.toggle('on', active);
        c.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
      applyLibrary();
    } else if (e.target.closest('[data-page-prev]')) {
      goTo(page - 1);
    } else if (e.target.closest('[data-page-next]')) {
      goTo(page + 1);
    } else if ((el = e.target.closest('[data-page-go]'))) {
      goTo(parseInt(el.getAttribute('data-page-go'), 10));
    }
  });

  var search = document.getElementById('q');
  if (search) search.addEventListener('input', applyLibrary);
  renderReader();
})();
